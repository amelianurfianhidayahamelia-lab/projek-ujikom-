<?php
include 'koneksi.php';
$id_anggota = $_SESSION['id_anggota'];

// ── PROSES KEMBALIKAN ─────────────────────────────────────────
if (isset($_GET['kembalikan'])) {
    $id = (int) $_GET['kembalikan'];

    $qTrx = mysqli_query($koneksi, "SELECT * FROM transaksi WHERE id=$id AND id_anggota=$id_anggota");
    $trx  = mysqli_fetch_assoc($qTrx);

    if ($trx && $trx['status'] === 'dipinjam') {
        $today  = date('Y-m-d');
        $status = (strtotime($today) > strtotime($trx['tanggal_jatuh_tempo'])) ? 'terlambat' : 'dikembalikan';

        mysqli_query($koneksi, "UPDATE transaksi SET
            tanggal_kembali='$today', status='$status'
            WHERE id=$id");
        mysqli_query($koneksi, "UPDATE buku SET stok = stok + 1 WHERE id={$trx['id_buku']}");

        $pesan_sukses = $status === 'terlambat'
            ? "Buku berhasil dikembalikan. Catatan: pengembalian terlambat dari jadwal."
            : "Buku berhasil dikembalikan tepat waktu. Terima kasih!";
    }
}

// ── FILTER ───────────────────────────────────────────────────
$filter  = $_GET['filter'] ?? 'dipinjam';
$allowed = ['semua', 'dipinjam', 'dikembalikan', 'terlambat'];
if (!in_array($filter, $allowed)) $filter = 'dipinjam';

$where = $filter !== 'semua' ? "AND t.status='$filter'" : '';

$data = mysqli_query($koneksi, "
    SELECT t.*, b.judul, b.pengarang, b.lokasi_rak
    FROM transaksi t
    JOIN buku b ON b.id = t.id_buku
    WHERE t.id_anggota=$id_anggota $where
    ORDER BY t.id DESC
");
?>

<?php if (!empty($pesan_sukses)): ?>
<div class="alert alert-success alert-dismissible fade show">
    <i class="bi bi-check-circle-fill me-2"></i><?= $pesan_sukses ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- Tab Filter -->
<div class="d-flex gap-2 mb-4">
    <?php foreach (['dipinjam'=>'Sedang Dipinjam','dikembalikan'=>'Sudah Kembali','terlambat'=>'Terlambat','semua'=>'Semua'] as $k => $v): ?>
    <a href="?page=pengembalian&filter=<?= $k ?>"
       class="btn btn-sm <?= $filter === $k ? 'btn-dark' : 'btn-outline-secondary' ?>">
        <?= $v ?>
    </a>
    <?php endforeach; ?>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>Buku</th>
                        <th class="text-center">Tgl Pinjam</th>
                        <th class="text-center">Jatuh Tempo</th>
                        <th class="text-center">Tgl Kembali</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($r = mysqli_fetch_assoc($data)):
                    $today     = date('Y-m-d');
                    $terlambat = ($r['status'] === 'dipinjam' && $today > $r['tanggal_jatuh_tempo']);
                ?>
                <tr <?= $terlambat ? 'class="table-warning"' : '' ?>>
                    <td>
                        <div class="fw-semibold"><?= htmlspecialchars($r['judul']) ?></div>
                        <small class="text-muted"><?= htmlspecialchars($r['pengarang']) ?> &bull; Rak <?= htmlspecialchars($r['lokasi_rak']) ?></small>
                    </td>
                    <td class="text-center"><?= date('d M Y', strtotime($r['tanggal_pinjam'])) ?></td>
                    <td class="text-center">
                        <?= date('d M Y', strtotime($r['tanggal_jatuh_tempo'])) ?>
                        <?php if ($terlambat): ?>
                        <br><small class="text-danger fw-bold">Sudah Terlambat!</small>
                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <?= $r['tanggal_kembali'] ? date('d M Y', strtotime($r['tanggal_kembali'])) : '<span class="text-muted">-</span>' ?>
                    </td>
                    <td class="text-center">
                        <?php
                        $badge = ['dipinjam'=>'primary','dikembalikan'=>'success','terlambat'=>'danger'];
                        $label = ['dipinjam'=>'Dipinjam','dikembalikan'=>'Dikembalikan','terlambat'=>'Terlambat'];
                        ?>
                        <span class="badge bg-<?= $badge[$r['status']] ?? 'secondary' ?>">
                            <?= $label[$r['status']] ?? $r['status'] ?>
                        </span>
                    </td>
                    <td class="text-center">
                        <?php if ($r['status'] === 'dipinjam'): ?>
                        <a href="?page=pengembalian&kembalikan=<?= $r['id'] ?>&filter=<?= $filter ?>"
                           class="btn btn-sm btn-success"
                           onclick="return confirm('Kembalikan buku ini sekarang?')">
                            <i class="bi bi-check-circle me-1"></i> Kembalikan
                        </a>
                        <?php else: ?>
                        <span class="text-muted">Selesai</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
                <?php if (mysqli_num_rows($data) === 0): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">Tidak ada data peminjaman.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
