-- ============================================================
--  Database: peminjaman_buku  (versi baru - bersih & terstruktur)
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";
SET NAMES utf8mb4;

DROP DATABASE IF EXISTS `peminjaman_buku`;
CREATE DATABASE `peminjaman_buku` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `peminjaman_buku`;

-- ------------------------------------------------------------
-- Tabel: admin
-- ------------------------------------------------------------
CREATE TABLE `admin` (
  `id`       INT          NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50)  NOT NULL,
  `password` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `admin` (`username`, `password`) VALUES ('amelia', 'amel1234');

-- ------------------------------------------------------------
-- Tabel: buku  (menggantikan crud_buku + tabel_buku)
-- ------------------------------------------------------------
CREATE TABLE `buku` (
  `id`          INT          NOT NULL AUTO_INCREMENT,
  `judul`       VARCHAR(150) NOT NULL,
  `pengarang`   VARCHAR(100) NOT NULL,
  `penerbit`    VARCHAR(100) NOT NULL,
  `tahun_terbit` YEAR        NOT NULL,
  `stok`        INT          NOT NULL DEFAULT 0,
  `lokasi_rak`  VARCHAR(25)  NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `buku` (`judul`, `pengarang`, `penerbit`, `tahun_terbit`, `stok`, `lokasi_rak`) VALUES
('Bumi Manusia',  'Pramoedya Ananta Toer', 'Lentera Dipantara',       1980, 4, 'A1'),
('Gadis Kretek',  'Ratih Kumala',          'Gramedia Pustaka Utama', 2012, 5, 'B2'),
('Laut Bercerita','Leila S. Chudori',      'Gramedia',               2017, 5, 'C3');

-- ------------------------------------------------------------
-- Tabel: anggota  (menggantikan crud_anggota + custumer)
-- Login sekaligus data keanggotaan
-- ------------------------------------------------------------
CREATE TABLE `anggota` (
  `id`             INT          NOT NULL AUTO_INCREMENT,
  `nomor_anggota`  VARCHAR(20)  NOT NULL,
  `nama`           VARCHAR(100) NOT NULL,
  `kelas`          VARCHAR(50)  NOT NULL,
  `jenis_kelamin`  ENUM('Laki-laki','Perempuan') NOT NULL,
  `tanggal_daftar` DATE         NOT NULL,
  `username`       VARCHAR(50)  NOT NULL,
  `password`       VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username`      (`username`),
  UNIQUE KEY `nomor_anggota` (`nomor_anggota`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `anggota` (`nomor_anggota`, `nama`, `kelas`, `jenis_kelamin`, `tanggal_daftar`, `username`, `password`) VALUES
('A001', 'Thalita',  'X MPLB', 'Perempuan', '2026-04-09', 'Thalita', 'lita123'),
('A002', 'Nazwa',    'X MPLB', 'Perempuan', '2026-04-06', 'Nazwa',   'nazwa123');

-- ------------------------------------------------------------
-- Tabel: transaksi  (menggantikan transaksi_peminjaman)
-- ------------------------------------------------------------
CREATE TABLE `transaksi` (
  `id`                  INT  NOT NULL AUTO_INCREMENT,
  `id_anggota`          INT  NOT NULL,
  `id_buku`             INT  NOT NULL,
  `tanggal_pinjam`      DATE NOT NULL,
  `tanggal_jatuh_tempo` DATE NOT NULL,
  `tanggal_kembali`     DATE DEFAULT NULL,
  `status`              ENUM('dipinjam','dikembalikan','terlambat') NOT NULL DEFAULT 'dipinjam',
  PRIMARY KEY (`id`),
  KEY `id_anggota` (`id_anggota`),
  KEY `id_buku`    (`id_buku`),
  CONSTRAINT `fk_anggota` FOREIGN KEY (`id_anggota`) REFERENCES `anggota` (`id`),
  CONSTRAINT `fk_buku`    FOREIGN KEY (`id_buku`)    REFERENCES `buku`    (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
