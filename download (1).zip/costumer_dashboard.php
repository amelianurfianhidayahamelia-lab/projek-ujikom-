<?php
include 'koneksi.php';
$id_anggota = $_SESSION['id_anggota'];

// Data anggota
$qAnggota = mysqli_query($koneksi, "SELECT * FROM anggota WHERE id=$id_anggota");
$anggota  = mysqli_fetch_assoc($qAnggota);

// Statistik
$totalPinjam   = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) c FROM transaksi WHERE id_anggota=$id_anggota"));
$sedangPinjam  = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) c FROM transaksi WHERE id_anggota=$id_anggota AND status='dipinjam'"));
$sudahKembali  = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) c FROM transaksi WHERE id_anggota=$id_anggota AND status IN('dikembalikan','terlambat')"));

// Riwayat terbaru
$riwayat = mysqli_query($koneksi, "
    SELECT t.*, b.judul
    FROM transaksi t
    JOIN buku b ON b.id = t.id_buku
    WHERE t.id_anggota=$id_anggota
    ORDER BY t.id DESC
    LIMIT 5
");
?>

<!-- Info Anggota -->
<div class="card shadow-sm mb-4" style="border-left: 4px solid #7b1fa2;">
    <div class="card-body d-flex align-items-center gap-3">
        <div style="background:#f3e5f5; border-radius:50%; width:56px; height:56px; display:flex; align-items:center; justify-content:center;">
            <i class="bi bi-person-fill fs-3" style="color:#7b1fa2;"></i>
        </div>
        <div>
            <div class="fw-bold fs-5"><?= htmlspecialchars($anggota['nama']) ?></div>
            <div class="text-muted" style="font-size:.875rem;">
                No. Anggota: <strong><?= htmlspecialchars($anggota['nomor_anggota']) ?></strong>
                &nbsp;|&nbsp; Kelas: <strong><?= htmlspecialchars($anggota['kelas']) ?></strong>
            </div>
        </div>
    </div>
</div>

<!-- Stat Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm text-center py-3">
            <div class="fs-2 fw-bold" style="color:#7b1fa2;"><?= $totalPinjam['c'] ?></div>
            <div class="text-muted">Total Peminjaman</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm text-center py-3">
            <div class="fs-2 fw-bold text-primary"><?= $sedangPinjam['c'] ?></div>
            <div class="text-muted">Sedang Dipinjam</div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm text-center py-3">
            <div class="fs-2 fw-bold text-success"><?= $sudahKembali['c'] ?></div>
            <div class="text-muted">Sudah Dikembalikan</div>
        </div>
    </div>
</div>

<!-- Riwayat Terbaru -->
<div class="card shadow-sm">
    <div class="card-header bg-white fw-bold d-flex justify-content-between align-items-center">
        Riwayat Peminjaman Terbaru
        <a href="?page=pengembalian" class="btn btn-sm btn-outline-secondary">Lihat Semua</a>
    </div>
    <div class="card-body p-0">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>Judul Buku</th>
                    <th class="text-center">Tgl Pinjam</th>
                    <th class="text-center">Jatuh Tempo</th>
                    <th class="text-center">Status</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($r = mysqli_fetch_assoc($riwayat)): ?>
            <?php $badge = ['dipinjam'=>'primary','dikembalikan'=>'success','terlambat'=>'danger']; ?>
            <tr>
                <td class="fw-semibold"><?= htmlspecialchars($r['judul']) ?></td>
                <td class="text-center"><?= date('d M Y', strtotime($r['tanggal_pinjam'])) ?></td>
                <td class="text-center"><?= date('d M Y', strtotime($r['tanggal_jatuh_tempo'])) ?></td>
                <td class="text-center">
                    <span class="badge bg-<?= $badge[$r['status']] ?? 'secondary' ?>">
                        <?= ucfirst($r['status']) ?>
                    </span>
                </td>
            </tr>
            <?php endwhile; ?>
            <?php if (!isset($r)): ?>
            <tr><td colspan="4" class="text-center text-muted py-4">Belum ada riwayat peminjaman.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
