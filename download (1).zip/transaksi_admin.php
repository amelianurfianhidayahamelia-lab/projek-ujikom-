<?php
include 'koneksi.php';

// ── PROSES PENGEMBALIAN OLEH ADMIN ───────────────────────────
if (isset($_GET['kembalikan'])) {
    $id = (int) $_GET['kembalikan'];

    $qTrx = mysqli_query($koneksi, "SELECT t.*, b.stok FROM transaksi t JOIN buku b ON b.id=t.id_buku WHERE t.id=$id");
    $trx  = mysqli_fetch_assoc($qTrx);

    if ($trx && $trx['status'] === 'dipinjam') {
        $today  = date('Y-m-d');
        $status = (strtotime($today) > strtotime($trx['tanggal_jatuh_tempo'])) ? 'terlambat' : 'dikembalikan';

        mysqli_query($koneksi, "UPDATE transaksi SET
            tanggal_kembali='$today', status='$status'
            WHERE id=$id");
        mysqli_query($koneksi, "UPDATE buku SET stok = stok + 1 WHERE id={$trx['id_buku']}");
    }
    header("Location: dashboard.php?halaman=transaksi");
    exit;
}

// ── FILTER STATUS ─────────────────────────────────────────────
$filter = $_GET['filter'] ?? 'semua';
$allowed_filter = ['semua', 'dipinjam', 'dikembalikan', 'terlambat'];
if (!in_array($filter, $allowed_filter)) $filter = 'semua';

$where = $filter !== 'semua' ? "WHERE t.status='$filter'" : '';

$data = mysqli_query($koneksi, "
    SELECT t.*, a.nama, a.kelas, a.nomor_anggota, b.judul
    FROM transaksi t
    JOIN anggota a ON a.id = t.id_anggota
    JOIN buku    b ON b.id = t.id_buku
    $where
    ORDER BY t.id DESC
");

// ── STATISTIK ─────────────────────────────────────────────────
$stat_dipinjam    = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) c FROM transaksi WHERE status='dipinjam'"));
$stat_kembali     = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) c FROM transaksi WHERE status='dikembalikan'"));
$stat_terlambat   = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) c FROM transaksi WHERE status='terlambat'"));
?>

<!-- Stat Cards -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm" style="border-left:4px solid #1565c0 !important;">
            <div class="card-body d-flex align-items-center gap-3">
                <div style="background:#e3f2fd; border-radius:50%; width:50px; height:50px; display:flex; align-items:center; justify-content:center;">
                    <i class="bi bi-bookmark-fill text-primary fs-5"></i>
                </div>
                <div>
                    <div class="text-muted" style="font-size:.8rem;">Sedang Dipinjam</div>
                    <div class="fw-bold fs-4"><?= $stat_dipinjam['c'] ?></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body d-flex align-items-center gap-3">
                <div style="background:#e8f5e9; border-radius:50%; width:50px; height:50px; display:flex; align-items:center; justify-content:center;">
                    <i class="bi bi-check-circle-fill text-success fs-5"></i>
                </div>
                <div>
                    <div class="text-muted" style="font-size:.8rem;">Sudah Dikembalikan</div>
                    <div class="fw-bold fs-4"><?= $stat_kembali['c'] ?></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body d-flex align-items-center gap-3">
                <div style="background:#fff3e0; border-radius:50%; width:50px; height:50px; display:flex; align-items:center; justify-content:center;">
                    <i class="bi bi-exclamation-triangle-fill text-warning fs-5"></i>
                </div>
                <div>
                    <div class="text-muted" style="font-size:.8rem;">Terlambat</div>
                    <div class="fw-bold fs-4"><?= $stat_terlambat['c'] ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filter & Tabel -->
<div class="card shadow-sm">
    <div class="card-header bg-white d-flex justify-content-between align-items-center">
        <span class="fw-bold">Data Transaksi Peminjaman</span>
        <div class="d-flex gap-2">
            <?php foreach (['semua'=>'Semua','dipinjam'=>'Dipinjam','dikembalikan'=>'Dikembalikan','terlambat'=>'Terlambat'] as $k => $v): ?>
            <a href="?halaman=transaksi&filter=<?= $k ?>"
               class="btn btn-sm <?= $filter === $k ? 'btn-dark' : 'btn-outline-secondary' ?>">
                <?= $v ?>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr class="text-center">
                        <th>ID</th>
                        <th class="text-start">Peminjam</th>
                        <th class="text-start">Buku</th>
                        <th>Tgl Pinjam</th>
                        <th>Jatuh Tempo</th>
                        <th>Tgl Kembali</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($r = mysqli_fetch_assoc($data)): ?>
                <?php
                    $today      = date('Y-m-d');
                    $terlambat  = ($r['status'] === 'dipinjam' && $today > $r['tanggal_jatuh_tempo']);
                ?>
                <tr <?= $terlambat ? 'class="table-warning"' : '' ?>>
                    <td class="text-center">#<?= $r['id'] ?></td>
                    <td>
                        <div class="fw-semibold"><?= htmlspecialchars($r['nama']) ?></div>
                        <small class="text-muted"><?= htmlspecialchars($r['kelas']) ?></small>
                    </td>
                    <td><?= htmlspecialchars($r['judul']) ?></td>
                    <td class="text-center"><?= date('d M Y', strtotime($r['tanggal_pinjam'])) ?></td>
                    <td class="text-center">
                        <?= date('d M Y', strtotime($r['tanggal_jatuh_tempo'])) ?>
                        <?php if ($terlambat): ?>
                            <br><small class="text-danger fw-bold">Terlambat!</small>
                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <?= $r['tanggal_kembali'] ? date('d M Y', strtotime($r['tanggal_kembali'])) : '<span class="text-muted">-</span>' ?>
                    </td>
                    <td class="text-center">
                        <?php
                        $badge = ['dipinjam' => 'primary', 'dikembalikan' => 'success', 'terlambat' => 'danger'];
                        $label = ['dipinjam' => 'Dipinjam', 'dikembalikan' => 'Dikembalikan', 'terlambat' => 'Terlambat'];
                        $b = $badge[$r['status']] ?? 'secondary';
                        $l = $label[$r['status']] ?? $r['status'];
                        ?>
                        <span class="badge bg-<?= $b ?>"><?= $l ?></span>
                    </td>
                    <td class="text-center">
                        <?php if ($r['status'] === 'dipinjam'): ?>
                        <a href="?halaman=transaksi&kembalikan=<?= $r['id'] ?>"
                           class="btn btn-sm btn-success"
                           onclick="return confirm('Proses pengembalian buku ini?')">
                            <i class="bi bi-check-circle me-1"></i> Kembalikan
                        </a>
                        <?php else: ?>
                        <span class="text-muted">-</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
                <?php if (mysqli_num_rows($data) === 0): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">Tidak ada data transaksi.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
