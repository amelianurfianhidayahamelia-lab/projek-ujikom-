<?php
include 'koneksi.php';

// ── TAMBAH / UPDATE ──────────────────────────────────────────
if (isset($_POST['simpan'])) {
    $nama      = mysqli_real_escape_string($koneksi, trim($_POST['nama']));
    $nomor     = mysqli_real_escape_string($koneksi, trim($_POST['nomor_anggota']));
    $kelas     = mysqli_real_escape_string($koneksi, trim($_POST['kelas']));
    $jk        = mysqli_real_escape_string($koneksi, $_POST['jenis_kelamin']);
    $tgl       = $_POST['tanggal_daftar'];
    $username  = mysqli_real_escape_string($koneksi, trim($_POST['username']));
    $password  = mysqli_real_escape_string($koneksi, trim($_POST['password']));

    if ($_POST['mode'] === 'tambah') {
        mysqli_query($koneksi, "INSERT INTO anggota
            (nomor_anggota, nama, kelas, jenis_kelamin, tanggal_daftar, username, password)
            VALUES ('$nomor','$nama','$kelas','$jk','$tgl','$username','$password')");
    } else {
        $id = (int) $_POST['id'];
        $pw_sql = $password ? ", password='$password'" : '';
        mysqli_query($koneksi, "UPDATE anggota SET
            nomor_anggota='$nomor', nama='$nama', kelas='$kelas',
            jenis_kelamin='$jk', tanggal_daftar='$tgl', username='$username'
            $pw_sql
            WHERE id=$id");
    }
    header("Location: dashboard.php?halaman=anggota");
    exit;
}

// ── HAPUS ────────────────────────────────────────────────────
if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    $cek = mysqli_query($koneksi, "SELECT id FROM transaksi WHERE id_anggota=$id AND status='dipinjam'");
    if (mysqli_num_rows($cek) > 0) {
        $pesan_error = "Anggota tidak bisa dihapus karena masih memiliki buku yang dipinjam!";
    } else {
        mysqli_query($koneksi, "DELETE FROM anggota WHERE id=$id");
        header("Location: dashboard.php?halaman=anggota");
        exit;
    }
}

// ── DATA EDIT ────────────────────────────────────────────────
$edit = null;
if (isset($_GET['edit'])) {
    $id   = (int) $_GET['edit'];
    $q    = mysqli_query($koneksi, "SELECT * FROM anggota WHERE id=$id");
    $edit = mysqli_fetch_assoc($q);
}

// ── DATA TABEL ───────────────────────────────────────────────
$data = mysqli_query($koneksi, "SELECT * FROM anggota ORDER BY id DESC");
?>

<?php if (!empty($pesan_error)): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <i class="bi bi-exclamation-triangle-fill me-2"></i><?= $pesan_error ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- Form Tambah / Edit -->
<div class="card shadow-sm mb-4">
    <div class="card-header fw-bold" style="background:#f3e5f5; color:#4a148c;">
        <i class="bi bi-<?= $edit ? 'pencil-square' : 'person-plus-fill' ?> me-2"></i>
        <?= $edit ? 'Edit Data Anggota' : 'Tambah Anggota Baru' ?>
    </div>
    <div class="card-body">
        <form method="POST">
            <input type="hidden" name="mode" value="<?= $edit ? 'edit' : 'tambah' ?>">
            <input type="hidden" name="id"   value="<?= $edit['id'] ?? '' ?>">

            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Nomor Anggota</label>
                    <input type="text" name="nomor_anggota" class="form-control"
                           value="<?= htmlspecialchars($edit['nomor_anggota'] ?? '') ?>"
                           placeholder="Contoh: A003" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Nama Lengkap</label>
                    <input type="text" name="nama" class="form-control"
                           value="<?= htmlspecialchars($edit['nama'] ?? '') ?>"
                           placeholder="Nama lengkap" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Kelas</label>
                    <input type="text" name="kelas" class="form-control"
                           value="<?= htmlspecialchars($edit['kelas'] ?? '') ?>"
                           placeholder="Contoh: X MPLB" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Jenis Kelamin</label>
                    <select name="jenis_kelamin" class="form-select" required>
                        <option value="">-- Pilih --</option>
                        <option value="Laki-laki"  <?= (($edit['jenis_kelamin'] ?? '') === 'Laki-laki')  ? 'selected' : '' ?>>Laki-laki</option>
                        <option value="Perempuan"  <?= (($edit['jenis_kelamin'] ?? '') === 'Perempuan')  ? 'selected' : '' ?>>Perempuan</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Tanggal Daftar</label>
                    <input type="date" name="tanggal_daftar" class="form-control"
                           value="<?= $edit['tanggal_daftar'] ?? date('Y-m-d') ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Username Login</label>
                    <input type="text" name="username" class="form-control"
                           value="<?= htmlspecialchars($edit['username'] ?? '') ?>"
                           placeholder="Username" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Password <?= $edit ? '<small class="text-muted">(kosongkan jika tidak diubah)</small>' : '' ?></label>
                    <input type="text" name="password" class="form-control"
                           placeholder="<?= $edit ? 'Kosongkan jika tidak diubah' : 'Password' ?>"
                           <?= !$edit ? 'required' : '' ?>>
                </div>
                <div class="col-md-3 d-flex align-items-end gap-2">
                    <button name="simpan" class="btn flex-grow-1" style="background:#7b1fa2; color:#fff;">
                        <i class="bi bi-save me-1"></i> <?= $edit ? 'Update' : 'Simpan' ?>
                    </button>
                    <?php if ($edit): ?>
                    <a href="dashboard.php?halaman=anggota" class="btn btn-outline-secondary">Batal</a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Tabel Anggota -->
<div class="card shadow-sm">
    <div class="card-header fw-bold bg-white">Daftar Anggota Perpustakaan</div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr class="text-center">
                        <th>No</th>
                        <th class="text-start">Nomor</th>
                        <th class="text-start">Nama</th>
                        <th>Kelas</th>
                        <th>JK</th>
                        <th>Tgl Daftar</th>
                        <th>Username</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php $no = 1; while ($a = mysqli_fetch_assoc($data)): ?>
                <tr>
                    <td class="text-center"><?= $no++ ?></td>
                    <td><span class="badge bg-secondary"><?= htmlspecialchars($a['nomor_anggota']) ?></span></td>
                    <td class="fw-semibold"><?= htmlspecialchars($a['nama']) ?></td>
                    <td class="text-center"><?= htmlspecialchars($a['kelas']) ?></td>
                    <td class="text-center"><?= $a['jenis_kelamin'] === 'Laki-laki' ? '<span class="badge bg-info text-dark">L</span>' : '<span class="badge bg-pink" style="background:#e91e63;">P</span>' ?></td>
                    <td class="text-center"><?= date('d M Y', strtotime($a['tanggal_daftar'])) ?></td>
                    <td class="text-center"><?= htmlspecialchars($a['username']) ?></td>
                    <td class="text-center">
                        <a href="dashboard.php?halaman=anggota&edit=<?= $a['id'] ?>" class="btn btn-sm btn-warning me-1">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <a href="dashboard.php?halaman=anggota&hapus=<?= $a['id'] ?>"
                           class="btn btn-sm btn-danger"
                           onclick="return confirm('Hapus anggota <?= htmlspecialchars($a['nama']) ?>?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endwhile; ?>
                <?php if (mysqli_num_rows($data) === 0): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">Belum ada anggota.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
