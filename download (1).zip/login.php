<?php
include 'koneksi.php';
session_start();

if ($_SESSION['login'] ?? false) {
    header("Location: " . ($_SESSION['role'] === 'admin' ? 'dashboard.php' : 'dashboard_costumer.php'));
    exit;
}

$error = '';

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, trim($_POST['username']));
    $password = mysqli_real_escape_string($koneksi, trim($_POST['password']));

    // Cek admin
    $qAdmin = mysqli_query($koneksi, "SELECT * FROM admin WHERE username='$username' AND password='$password'");
    if ($qAdmin && mysqli_num_rows($qAdmin) > 0) {
        $data = mysqli_fetch_assoc($qAdmin);
        $_SESSION['login']    = true;
        $_SESSION['role']     = 'admin';
        $_SESSION['username'] = $data['username'];
        header("Location: dashboard.php");
        exit;
    }

    // Cek anggota
    $qAnggota = mysqli_query($koneksi, "SELECT * FROM anggota WHERE username='$username' AND password='$password'");
    if ($qAnggota && mysqli_num_rows($qAnggota) > 0) {
        $data = mysqli_fetch_assoc($qAnggota);
        $_SESSION['login']       = true;
        $_SESSION['role']        = 'anggota';
        $_SESSION['id_anggota']  = $data['id'];
        $_SESSION['username']    = $data['username'];
        $_SESSION['nama']        = $data['nama'];
        header("Location: dashboard_costumer.php");
        exit;
    }

    $error = "Username atau password salah!";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - Perpustakaan Sekolah</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #7b1fa2, #4a148c);
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .login-card {
            background: #fff;
            padding: 45px 40px;
            width: 380px;
            border-radius: 16px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.25);
            animation: fadeIn 0.6s ease;
        }
        .login-card .logo {
            text-align: center;
            margin-bottom: 28px;
        }
        .login-card .logo i {
            font-size: 2.5rem;
            color: #7b1fa2;
        }
        .login-card h2 {
            text-align: center;
            color: #333;
            font-size: 1.4rem;
            margin-bottom: 6px;
        }
        .login-card p.sub {
            text-align: center;
            color: #888;
            font-size: 0.85rem;
            margin-bottom: 28px;
        }
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; font-size: 0.85rem; color: #555; margin-bottom: 6px; }
        .form-group input {
            width: 100%;
            padding: 11px 14px;
            border: 1.5px solid #ddd;
            border-radius: 8px;
            font-size: 0.95rem;
            outline: none;
            transition: 0.25s;
        }
        .form-group input:focus { border-color: #7b1fa2; box-shadow: 0 0 0 3px rgba(123,31,162,0.12); }
        .btn-login {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #7b1fa2, #4a148c);
            border: none;
            color: #fff;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: 0.25s;
            margin-top: 4px;
        }
        .btn-login:hover { opacity: 0.9; transform: translateY(-1px); }
        .alert-error {
            background: #fce4ec;
            color: #c62828;
            border-radius: 8px;
            padding: 10px 14px;
            font-size: 0.875rem;
            margin-bottom: 18px;
            border-left: 4px solid #e53935;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-16px); }
            to   { opacity: 1; transform: translateY(0); }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="login-card">
    <div class="logo"><i class="fas fa-book-open"></i></div>
    <h2>Perpustakaan Sekolah</h2>
    <p class="sub">Silakan masuk untuk melanjutkan</p>

    <?php if ($error): ?>
    <div class="alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" placeholder="Masukkan username" required autofocus>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Masukkan password" required>
        </div>
        <button type="submit" name="login" class="btn-login">Masuk</button>
    </form>
</div>
</body>
</html>
