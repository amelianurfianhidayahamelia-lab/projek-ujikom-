<?php
$host    = "sql206.infinityfree.com";
$user    = "if0_41636371";
$pass    = "FJ5FtNWC3Wyu";
$db      = "if0_41636371_my_db";

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

mysqli_set_charset($koneksi, "utf8mb4");
?>
