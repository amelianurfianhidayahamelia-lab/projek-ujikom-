<?php
include 'koneksi.php';
$id_anggota = $_SESSION['id_anggota'];

// ── PROSES PINJAM ─────────────────────────────────────────────
if (isset($_GET['pinjam'])) {
    $id_buku = (int) $_GET['pinjam'];

    // Cek apakah anggota sudah meminjam buku ini & belum dikembalikan
    $cekDuplikat = mysqli_query($koneksi, "
        SELECT id FROM transaksi
        WHERE id_anggota=$id_anggota AND id_buku=$id_buku AND status='dipinjam'
    ");
    if (mysqli_num_rows($cekDuplikat) > 0) {
        $pesan_error = "Kamu sudah meminjam buku ini dan belum mengembalikannya!";
    } else {
        // Cek stok
        $qBuku = mysqli_query($koneksi, "SELECT stok FROM buku WHERE id=$id_buku");
        $buku  = mysqli_fetch_assoc($qBuku);

        if ($buku && $buku['stok'] > 0) {
            $tgl_pinjam = date('Y-m-d');
            $jatuh_tempo = date('Y-m-d', strtotime('+7 days'));

            mysqli_query($koneksi, "INSERT INTO transaksi
                (id_anggota, id_buku, tanggal_pinjam, tanggal_jatuh_tempo, status)
                VALUES ($id_anggota, $id_buku, '$tgl_pinjam', '$jatuh_tempo', 'dipinjam')");
            mysqli_query($koneksi, "UPDATE buku SET stok = stok - 1 WHERE id=$id_buku");

            $pesan_sukses = "Buku berhasil dipinjam! Harap dikembalikan sebelum $jatuh_tempo.";
        } else {
            $pesan_error = "Stok buku habis, tidak bisa dipinjam saat ini.";
        }
    }
}

// ── DATA BUKU ─────────────────────────────────────────────────
$keyword = '';
if (isset($_GET['cari'])) {
    $keyword = mysqli_real_escape_string($koneksi, trim($_GET['cari']));
}
$where = $keyword ? "WHERE judul LIKE '%$keyword%' OR pengarang LIKE '%$keyword%'" : '';
$buku  = mysqli_query($koneksi, "SELECT * FROM buku $where ORDER BY judul ASC");
?>

<?php if (!empty($pesan_sukses)): ?>
<div class="alert alert-success alert-dismissible fade show">
    <i class="bi bi-check-circle-fill me-2"></i><?= $pesan_sukses ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if (!empty($pesan_error)): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <i class="bi bi-exclamation-triangle-fill me-2"></i><?= $pesan_error ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- Form Cari -->
<form method="GET" action="dashboard_costumer.php" class="mb-4">
    <input type="hidden" name="page" value="pinjam">
    <div class="input-group" style="max-width: 450px;">
        <input type="text" name="cari" class="form-control"
               placeholder="Cari judul atau pengarang..."
               value="<?= htmlspecialchars($keyword) ?>">
        <button class="btn btn-outline-secondary">Cari</button>
        <?php if ($keyword): ?>
        <a href="?page=pinjam" class="btn btn-outline-danger">Reset</a>
        <?php endif; ?>
    </div>
</form>

<!-- Daftar Buku -->
<div class="row g-3">
<?php while ($b = mysqli_fetch_assoc($buku)): ?>
<div class="col-md-6 col-lg-4">
    <div class="card h-100 shadow-sm <?= $b['stok'] == 0 ? 'opacity-75' : '' ?>">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <span class="badge bg-secondary"><?= htmlspecialchars($b['lokasi_rak']) ?></span>
                <?php if ($b['stok'] > 0): ?>
                    <span class="badge bg-success"><?= $b['stok'] ?> tersedia</span>
                <?php else: ?>
                    <span class="badge bg-danger">Habis</span>
                <?php endif; ?>
            </div>
            <h6 class="fw-bold mb-1"><?= htmlspecialchars($b['judul']) ?></h6>
            <p class="text-muted mb-1" style="font-size:.85rem;"><?= htmlspecialchars($b['pengarang']) ?></p>
            <p class="text-muted mb-0" style="font-size:.8rem;">
                <?= htmlspecialchars($b['penerbit']) ?> &bull; <?= $b['tahun_terbit'] ?>
            </p>
        </div>
        <div class="card-footer bg-transparent border-top pt-2 pb-3">
            <?php if ($b['stok'] > 0): ?>
                <a href="?page=pinjam&pinjam=<?= $b['id'] ?>"
                   class="btn btn-sm w-100"
                   style="background:#7b1fa2; color:#fff;"
                   onclick="return confirm('Pinjam buku &quot;<?= htmlspecialchars($b['judul']) ?>&quot;?\nMasa pinjam 7 hari.')">
                    <i class="bi bi-bookmark-plus me-1"></i> Pinjam Sekarang
                </a>
            <?php else: ?>
                <button class="btn btn-sm btn-secondary w-100" disabled>
                    <i class="bi bi-x-circle me-1"></i> Tidak Tersedia
                </button>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endwhile; ?>
<?php if (mysqli_num_rows($buku) === 0): ?>
<div class="col-12">
    <div class="alert alert-info">Tidak ada buku yang ditemukan.</div>
</div>
<?php endif; ?>
</div>
