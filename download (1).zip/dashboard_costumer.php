<?php
session_start();

if (!isset($_SESSION['login']) || $_SESSION['role'] !== 'anggota') {
    header("Location: login.php");
    exit;
}

$page    = $_GET['page'] ?? 'home';
$allowed = ['home', 'pinjam', 'pengembalian'];
if (!in_array($page, $allowed)) {
    $page = 'home';
}

$menu = [
    'home'         => ['icon' => 'bi-grid-1x2-fill',   'label' => 'Dashboard'],
    'pinjam'       => ['icon' => 'bi-bookmark-plus',    'label' => 'Pinjam Buku'],
    'pengembalian' => ['icon' => 'bi-arrow-left-right', 'label' => 'Pengembalian'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard - Perpustakaan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        :root { --purple: #7b1fa2; --dark-purple: #4a148c; --light-purple: #f3e5f5; }
        body { background: #f5f5f5; font-family: 'Segoe UI', sans-serif; }

        .navbar-top {
            background: linear-gradient(135deg, var(--purple), var(--dark-purple));
            padding: 12px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }
        .navbar-top .brand { color: #fff; font-weight: 700; font-size: 1.05rem; }
        .navbar-top .brand i { margin-right: 8px; }
        .navbar-top .right { color: #e1bee7; font-size: 0.9rem; }
        .navbar-top .right a { color: #fff; background: rgba(255,255,255,0.15); padding: 6px 16px; border-radius: 20px; text-decoration: none; font-size: 0.85rem; margin-left: 14px; border: 1px solid rgba(255,255,255,0.3); }
        .navbar-top .right a:hover { background: rgba(255,255,255,0.25); }

        .sidebar {
            width: 220px;
            min-height: calc(100vh - 54px);
            background: #fff;
            border-right: 1px solid #e0e0e0;
            padding: 20px 0;
            position: fixed;
            top: 54px;
            left: 0;
        }
        .sidebar .menu-label {
            font-size: 0.7rem;
            color: #aaa;
            text-transform: uppercase;
            font-weight: 700;
            padding: 0 20px 8px;
            letter-spacing: 0.05em;
        }
        .sidebar a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 11px 20px;
            color: #555;
            text-decoration: none;
            font-size: 0.9rem;
            margin: 2px 10px;
            border-radius: 8px;
            transition: 0.2s;
        }
        .sidebar a i { font-size: 1.05rem; width: 20px; }
        .sidebar a:hover { background: var(--light-purple); color: var(--purple); }
        .sidebar a.active { background: var(--light-purple); color: var(--purple); font-weight: 600; }

        .main-content { margin-left: 220px; padding: 28px; min-height: calc(100vh - 54px); }
        .page-title { font-size: 1.3rem; font-weight: 700; color: #333; margin-bottom: 20px; }
        .page-title span { color: var(--purple); }
        footer { text-align: center; color: #aaa; font-size: 0.78rem; padding: 20px 0 10px; }
    </style>
</head>
<body>

<div class="navbar-top">
    <div class="brand"><i class="bi bi-book-half"></i> PERPUSTAKAAN SEKOLAH</div>
    <div class="right">
        <i class="bi bi-person-circle"></i> <?= htmlspecialchars($_SESSION['nama']) ?>
        <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
</div>

<div class="sidebar">
    <div class="menu-label">Menu</div>
    <?php foreach ($menu as $key => $item): ?>
    <a href="?page=<?= $key ?>" class="<?= $page === $key ? 'active' : '' ?>">
        <i class="bi <?= $item['icon'] ?>"></i> <?= $item['label'] ?>
    </a>
    <?php endforeach; ?>
</div>

<div class="main-content">
    <div class="page-title"><span><?= $menu[$page]['label'] ?></span></div>

    <?php
    switch ($page) {
        case 'home':
            include 'costumer_dashboard.php';
            break;
        case 'pinjam':
            include 'pinjam_buku.php';
            break;
        case 'pengembalian':
            include 'pengembalian_dashboard.php';
            break;
    }
    ?>

    <footer>Copyright &copy; <?= date('Y') ?> Perpustakaan Sekolah</footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
