<?php
include 'koneksi.php';

// ── TAMBAH / UPDATE ──────────────────────────────────────────
if (isset($_POST['simpan'])) {
    $judul    = mysqli_real_escape_string($koneksi, trim($_POST['judul']));
    $pengarang = mysqli_real_escape_string($koneksi, trim($_POST['pengarang']));
    $penerbit  = mysqli_real_escape_string($koneksi, trim($_POST['penerbit']));
    $tahun     = (int) $_POST['tahun_terbit'];
    $stok      = (int) $_POST['stok'];
    $rak       = mysqli_real_escape_string($koneksi, trim($_POST['lokasi_rak']));

    if ($_POST['mode'] === 'tambah') {
        mysqli_query($koneksi, "INSERT INTO buku (judul, pengarang, penerbit, tahun_terbit, stok, lokasi_rak)
            VALUES ('$judul','$pengarang','$penerbit','$tahun','$stok','$rak')");
    } else {
        $id = (int) $_POST['id'];
        mysqli_query($koneksi, "UPDATE buku SET
            judul='$judul', pengarang='$pengarang', penerbit='$penerbit',
            tahun_terbit='$tahun', stok='$stok', lokasi_rak='$rak'
            WHERE id=$id");
    }
    header("Location: dashboard.php?halaman=buku");
    exit;
}

// ── HAPUS ────────────────────────────────────────────────────
if (isset($_GET['hapus'])) {
    $id = (int) $_GET['hapus'];
    // Cek apakah buku masih dipinjam
    $cek = mysqli_query($koneksi, "SELECT id FROM transaksi WHERE id_buku=$id AND status='dipinjam'");
    if (mysqli_num_rows($cek) > 0) {
        $pesan_error = "Buku tidak bisa dihapus karena masih dipinjam!";
    } else {
        mysqli_query($koneksi, "DELETE FROM buku WHERE id=$id");
        header("Location: dashboard.php?halaman=buku");
        exit;
    }
}

// ── DATA EDIT ────────────────────────────────────────────────
$edit = null;
if (isset($_GET['edit'])) {
    $id   = (int) $_GET['edit'];
    $q    = mysqli_query($koneksi, "SELECT * FROM buku WHERE id=$id");
    $edit = mysqli_fetch_assoc($q);
}

// ── DATA TABEL ───────────────────────────────────────────────
$keyword = '';
if (isset($_GET['cari'])) {
    $keyword = mysqli_real_escape_string($koneksi, trim($_GET['cari']));
}
$where = $keyword ? "WHERE judul LIKE '%$keyword%' OR pengarang LIKE '%$keyword%' OR penerbit LIKE '%$keyword%'" : '';
$data  = mysqli_query($koneksi, "SELECT * FROM buku $where ORDER BY id DESC");
?>

<?php if (!empty($pesan_error)): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="bi bi-exclamation-triangle-fill me-2"></i><?= $pesan_error ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- Form Tambah / Edit -->
<div class="card shadow-sm mb-4">
    <div class="card-header fw-bold" style="background:#f3e5f5; color:#4a148c;">
        <i class="bi bi-<?= $edit ? 'pencil-square' : 'plus-circle' ?> me-2"></i>
        <?= $edit ? 'Edit Data Buku' : 'Tambah Buku Baru' ?>
    </div>
    <div class="card-body">
        <form method="POST">
            <input type="hidden" name="mode"  value="<?= $edit ? 'edit'        : 'tambah' ?>">
            <input type="hidden" name="id"    value="<?= $edit ? $edit['id']   : '' ?>">

            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Judul Buku</label>
                    <input type="text" name="judul" class="form-control"
                           value="<?= htmlspecialchars($edit['judul'] ?? '') ?>"
                           placeholder="Contoh: Bumi Manusia" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Pengarang</label>
                    <input type="text" name="pengarang" class="form-control"
                           value="<?= htmlspecialchars($edit['pengarang'] ?? '') ?>"
                           placeholder="Nama pengarang" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Penerbit</label>
                    <input type="text" name="penerbit" class="form-control"
                           value="<?= htmlspecialchars($edit['penerbit'] ?? '') ?>"
                           placeholder="Nama penerbit" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Tahun Terbit</label>
                    <input type="number" name="tahun_terbit" class="form-control" min="1900" max="<?= date('Y') ?>"
                           value="<?= $edit['tahun_terbit'] ?? date('Y') ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Jumlah Stok</label>
                    <input type="number" name="stok" class="form-control" min="0"
                           value="<?= $edit['stok'] ?? '' ?>"
                           placeholder="0" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Lokasi Rak</label>
                    <input type="text" name="lokasi_rak" class="form-control"
                           value="<?= htmlspecialchars($edit['lokasi_rak'] ?? '') ?>"
                           placeholder="Contoh: A1" required>
                </div>
                <div class="col-md-3 d-flex align-items-end gap-2">
                    <button name="simpan" class="btn btn-purple flex-grow-1"
                            style="background:#7b1fa2; color:#fff;">
                        <i class="bi bi-save me-1"></i>
                        <?= $edit ? 'Update' : 'Simpan' ?>
                    </button>
                    <?php if ($edit): ?>
                    <a href="dashboard.php?halaman=buku" class="btn btn-outline-secondary">Batal</a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Tabel Buku -->
<div class="card shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center bg-white">
        <span class="fw-bold">Daftar Koleksi Buku</span>
        <form method="GET" action="dashboard.php" class="d-flex gap-2">
            <input type="hidden" name="halaman" value="buku">
            <input type="text" name="cari" class="form-control form-control-sm" style="width:200px;"
                   placeholder="Cari judul / pengarang..." value="<?= htmlspecialchars($keyword) ?>">
            <button class="btn btn-sm btn-outline-secondary">Cari</button>
            <?php if ($keyword): ?>
            <a href="dashboard.php?halaman=buku" class="btn btn-sm btn-outline-danger">Reset</a>
            <?php endif; ?>
        </form>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr class="text-center">
                        <th width="50">No</th>
                        <th class="text-start">Judul</th>
                        <th class="text-start">Pengarang</th>
                        <th>Tahun</th>
                        <th>Stok</th>
                        <th>Rak</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php $no = 1; while ($b = mysqli_fetch_assoc($data)): ?>
                <tr>
                    <td class="text-center"><?= $no++ ?></td>
                    <td class="fw-semibold"><?= htmlspecialchars($b['judul']) ?></td>
                    <td><?= htmlspecialchars($b['pengarang']) ?></td>
                    <td class="text-center"><?= $b['tahun_terbit'] ?></td>
                    <td class="text-center">
                        <?php if ($b['stok'] > 0): ?>
                            <span class="badge bg-success rounded-pill"><?= $b['stok'] ?> tersedia</span>
                        <?php else: ?>
                            <span class="badge bg-danger rounded-pill">Habis</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-center"><span class="badge bg-secondary"><?= htmlspecialchars($b['lokasi_rak']) ?></span></td>
                    <td class="text-center">
                        <a href="dashboard.php?halaman=buku&edit=<?= $b['id'] ?>" class="btn btn-sm btn-warning me-1">
                            <i class="bi bi-pencil"></i>
                        </a>
                        <a href="dashboard.php?halaman=buku&hapus=<?= $b['id'] ?>"
                           class="btn btn-sm btn-danger"
                           onclick="return confirm('Hapus buku ini?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endwhile; ?>
                <?php if (mysqli_num_rows($data) === 0): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">Tidak ada data buku.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
